import React from 'react';
import {createDrawerNavigator} from 'react-navigation-drawer';
import { AppTabNavigator } from './AppTabNavigator'
import CustomSideBarMenu  from './CustomSideBarMenu';
import MyDonationScreen from '../Screens/MyDonationScreen';
import SettingScreen from '../Screens/SettingScreen';
import NotificationScreen from '../Screens/NotificationScreen'
import MyReceivedBooksScreen from '../Screens/MyReceivedBooksScreen'
export const AppDrawerNavigator = createDrawerNavigator({
  Home : {
    screen : AppTabNavigator
    },
  MyDonations : {
    screen : MyDonationScreen
  },
  MyRecieves :{
    screen: MyReceivedBooksScreen
  },
   Notification : {
    screen : NotificationScreen
  },
  Setting : {
    screen : SettingScreen
  }
},
  {
    contentComponent:CustomSideBarMenu
  },
  {
    initialRouteName : 'Home'
  })