import React from 'react';
import {Image} from 'react-native'
//import LottieView from 'lottie-react-native';
import Animation from 'lottie-react-native';
import * as lottieWeb from 'react-native-web-lottie'

export default class SantaAnimation extends React.Component {
  render() {
    return (
     /*<LottieView
      source={require('../13015-santa-claus.json')}
      style={{width:"60%"}}
      autoPlay loop />*/

      <Image 
      source={'https://bestanimations.com/media/santa-claus/583616233d-santa-computer.gif'}
      style={{width:200, height:200}}
      />
      
    )
  }
}