import * as firebase from 'firebase';
import 'firebase/firestore';
require('@firebase/firestore');

const firebaseConfig = {
  apiKey: "AIzaSyCIF0sGTKgil6wBTpivyfG3T_AVUqjugr8",
  authDomain: "wily-app-6216c.firebaseapp.com",
  projectId: "wily-app-6216c",
  storageBucket: "wily-app-6216c.appspot.com",
  messagingSenderId: "1077009263130",
  appId: "1:1077009263130:web:a3d16d37fe935f6d51bfa3"
};
// Initialize Firebase
if (!firebase.apps.length) {
  firebase.initializeApp(firebaseConfig);
} else {
  firebase.app(); // if already initialized, use that one
}

export default firebase.firestore();
