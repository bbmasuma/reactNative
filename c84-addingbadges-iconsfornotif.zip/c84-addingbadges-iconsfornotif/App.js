import React from 'react';
import { createAppContainer, createSwitchNavigator,} from 'react-navigation';

import WelcomeScreen from './Screens/WelcomeScreen';
import { AppDrawerNavigator } from './components/AppDrawerNavigator'
import { AppTabNavigator } from './components/AppTabNavigator'
import {AppStackNavigator} from './components/AppStackNavigator'
import RecieverDetailsScreen from './Screens/RecieverDetailsScreen'
import BookDonateScreen from './Screens/BookDonateScreen'

export default function App() {
  return (
    <AppContainer/>
  );
}


const switchNavigator = createSwitchNavigator({
  WelcomeScreen:{screen: WelcomeScreen},
  Drawer:{screen: AppDrawerNavigator},
  BottomTab: {screen: AppTabNavigator},
  RecieverDetails:{screen:RecieverDetailsScreen},
  BookDonateList:{screen:BookDonateScreen}
})

const AppContainer =  createAppContainer(switchNavigator);