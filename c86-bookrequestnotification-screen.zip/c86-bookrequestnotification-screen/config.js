import firebase from 'firebase';
require('@firebase/firestore')

const firebaseConfig = {
    apiKey: "AIzaSyAD5-L3sDaeBm5dE1CYQhigjQpHvk1DNVs",
    authDomain: "booksanta-89dd3.firebaseapp.com",
    projectId: "booksanta-89dd3",
    storageBucket: "booksanta-89dd3.appspot.com",
    messagingSenderId: "78149665649",
    appId: "1:78149665649:web:8ea931c8c05b0ccc7c2cd0"
  };


firebase.initializeApp(firebaseConfig);

  export default firebase.firestore();